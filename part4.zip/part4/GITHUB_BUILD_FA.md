# کامپایل روی GitHub

1. یک ریپوی جدید در GitHub بساز (ترجیحاً Private، چون شامل فایل‌های Rockstar است).
2. همه‌ی محتوای این پوشه را در ریپو آپلود کن (پوشه‌ی `.github` هم باید باشد).
3. به تب **Actions** برو. بیلد با هر push خودکار شروع می‌شود، یا گزینه‌ی **Run workflow** را بزن.
4. بعد از ۲۰ تا ۴۰ دقیقه، داخل همان اجرا در بخش **Artifacts** فایل `Dexin-Mobile-APK` را دانلود کن.

## کلید امضای ثابت (توصیه می‌شود)
بدون کلید، هر بار یک کلید موقت ساخته می‌شود و APK جدید روی نسخه‌ی قبلی نصب نمی‌شود.
1. یک بار روی کامپیوتر: `keytool -genkeypair -keystore dexin.jks -alias dexin -keyalg RSA -keysize 2048 -validity 10000`
2. تبدیل به base64: لینوکس/مک `base64 -w0 dexin.jks` ، ویندوز PowerShell `[Convert]::ToBase64String([IO.File]::ReadAllBytes("dexin.jks"))`
3. در GitHub: Settings ← Secrets and variables ← Actions ← New repository secret:
   - KEYSTORE_BASE64
   - KEYSTORE_PASSWORD
   - KEY_ALIAS
   - KEY_PASSWORD
فایل `.jks` را هرگز در ریپو نگذار و نگهش دار.
