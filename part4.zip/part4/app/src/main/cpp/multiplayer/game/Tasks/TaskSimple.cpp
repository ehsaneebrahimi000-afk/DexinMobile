//
// Created by GLORY TEAM.
//

#include "TaskSimple.h"

CTaskSimple::CTaskSimple() {
    m_pParentTask = nullptr;
}

// 0x43E300
CTask* CTaskSimple::GetSubTask() {
    return nullptr;
}

// 0x43E310
bool CTaskSimple::IsSimple() {
    return true;
}

// 0x43E320
bool CTaskSimple::SetPedPosition(CPedGTA* ped) {
    return false;
}
