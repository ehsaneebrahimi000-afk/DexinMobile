#include "../main.h"
#include "game.h"
#include "../net/netgame.h"
#include "vehicle.h"
#include "Streaming.h"
#include "CHandlingDefault.h"
#include "game/Models/ModelInfo.h"

extern CGame* pGame;
extern CNetGame* pNetGame;

bool bInProcessDetachTrailer = false;

CVehicle::CVehicle(int iType, float fX, float fY, float fZ, float fRotation, bool bPreloaded, bool bSiren)
{
	FLog("CVehicle %d %f %f %f %f %d", iType, fX, fY, fZ, fRotation, bSiren);
	RwMatrix matEnt;
	static CVehicleGTA* pCreatedTrain = nullptr;

	m_pVehicle = nullptr;
	m_dwGTAId = 0;
	m_pTrailer = nullptr;

	if ((iType != TRAIN_PASSENGER_LOCO) &&
		(iType != TRAIN_FREIGHT_LOCO) &&
		(iType != TRAIN_PASSENGER) &&
		(iType != TRAIN_FREIGHT) &&
		(iType != TRAIN_TRAM)) {

        if (!CStreaming::TryLoadModel(iType))
		{
			FLog("veh model %d not found", iType);
            return;
		}
		ScriptCommand(&create_car, iType, fX, fY, fZ, &m_dwGTAId);
		ScriptCommand(&set_car_z_angle, m_dwGTAId, fRotation);
		ScriptCommand(&car_gas_tank_explosion, m_dwGTAId, 0);
		ScriptCommand(&set_car_hydraulics, m_dwGTAId, 0);
		ScriptCommand(&toggle_car_tires_vulnerable, m_dwGTAId, 0);

		m_pVehicle = GamePool_Vehicle_GetAt(m_dwGTAId);

		if (m_pVehicle) 
		{
			m_pVehicle->m_nDoorLock = (eCarLock)0;
			m_bIsLocked = false;

			m_pVehicle->GetMatrix(&matEnt);
			matEnt.pos.x = fX;
			matEnt.pos.y = fY;
			matEnt.pos.z = fZ;

			if( GetVehicleSubtype() != VEHICLE_SUBTYPE_BIKE &&
				GetVehicleSubtype() != VEHICLE_SUBTYPE_PUSHBIKE)
				matEnt.pos.z += 0.25f;

			m_pVehicle->SetMatrix((CMatrix&)matEnt);
			m_bPreloaded = bPreloaded;
		}

		//Remove();
		//pGame->RemoveModel(iType, false);
	}
	else if ((iType == TRAIN_PASSENGER_LOCO) ||
		(iType == TRAIN_FREIGHT_LOCO) ||
		(iType == TRAIN_TRAM))
	{
		if (iType == TRAIN_PASSENGER_LOCO) iType = 5;
		else if (iType == TRAIN_FREIGHT_LOCO) iType = 3;
		else if (iType == TRAIN_TRAM) iType = 9;

		uint32_t dwDirection = 0;
		if (fRotation > 180.0f) {
			dwDirection = 1;
		}

        if (!CStreaming::TryLoadModel(TRAIN_PASSENGER_LOCO)) {
			FLog("Model not loaded");
			return;
		} 

        if (!CStreaming::TryLoadModel(TRAIN_PASSENGER)) {
			FLog("Model not loaded");
			return;
		} 
        if (!CStreaming::TryLoadModel(TRAIN_FREIGHT_LOCO)) {
			FLog("Model not loaded");
			return;
		} 
        if (!CStreaming::TryLoadModel(TRAIN_FREIGHT)) {
			FLog("Model not loaded");
			return;
		} 
        if (!CStreaming::TryLoadModel(TRAIN_TRAM)) {
			FLog("Model not loaded");
			return;
		} 
		ScriptCommand(&create_train, iType, fX, fY, fZ, dwDirection, &m_dwGTAId);
		m_pVehicle = GamePool_Vehicle_GetAt(m_dwGTAId);

		pCreatedTrain = m_pVehicle;

		GamePrepareTrain(m_pVehicle);
	}
	else if ((iType == TRAIN_PASSENGER) ||
		(iType == TRAIN_FREIGHT))
	{
		if (!pCreatedTrain)
		{
			m_pVehicle = nullptr;
			return;
		}

		m_dwGTAId = GamePool_Vehicle_GetIndex(m_pVehicle);
		pCreatedTrain = m_pVehicle;
	}

	m_bIsInvulnerable = false;
	m_byteObjectiveVehicle = 0;
	m_bSpecialMarkerEnabled = false;
	m_dwMarkerID = 0;
	//_this->field_6D = 0;
	//_this->field_69 = GetTickCount();
	m_iEngineState = -1;
	m_iLightState = -1;
	m_bDoorsLocked = false;
	m_bHaveColor = false;
	m_bHasBeenDriven = false;
	m_dwTimeSinceLastDriven = GetTickCount();
	//_this->field_71 = 0;
	//_this->field_75 = 0;
	//_this->field_8F = 0;
	memset(m_szPlateText, 0, sizeof(m_szPlateText));
}

CVehicle::~CVehicle()
{
	m_pVehicle = GamePool_Vehicle_GetAt(m_dwGTAId);

	if (m_pVehicle) {
        auto modelId = m_pVehicle->m_nModelIndex;
		if(m_dwMarkerID)
		{
			pGame->DisableMarker(m_dwMarkerID);
			m_dwMarkerID = 0;
		}

		RemoveEveryoneFromVehicle();

		if(SirenEnabled()) EnableSiren(false);

		if (m_pTrailer) {
			DetachTrailer();
			m_pTrailer = nullptr;
		}

		int iModel = m_pVehicle->m_nModelIndex;
		if (iModel == 538 || iModel == 537)
		{
			ScriptCommand(&destroy_train, m_dwGTAId);
		}
		else
		{
			ScriptCommand(&destroy_car, m_dwGTAId);
		}

        CStreaming::RemoveModelIfNoRefs(modelId);
	}
}
// 0.3.7
bool CVehicle::IsRCVehicle()
{
	if (m_pVehicle)
	{
		if (GamePool_Vehicle_GetAt(m_dwGTAId))
		{
			int iModel = m_pVehicle->m_nModelIndex;
			if (iModel == 441
				|| iModel == 464
				|| iModel == 465
				|| iModel == 594
				|| iModel == 501
				|| iModel == 564) {
				return true;
			}
		}
	}

	return false;
}
// 0.3.7
float CVehicle::GetHealth()
{
    if(m_pVehicle) return m_pVehicle->fHealth;
    else return 0.0f;
}
// 0.3.7
void CVehicle::SetHealth(float fHealth)
{
	if (m_pVehicle) {
		m_pVehicle->fHealth = fHealth;
	}
}
// 0.3.7
int CVehicle::GetVehicleSubtype()
{
	if (m_pVehicle) {
		return ::GetVehicleSubtype(m_pVehicle);
	}

	return 0;
}
// 0.3.7
void CVehicle::AddComponent(int iComponentID)
{
	if (!m_pVehicle || !GamePool_Vehicle_GetAt(m_dwGTAId)) return;
	if (GetVehicleSubtype() != VEHICLE_SUBTYPE_CAR) return;

    if (!CStreaming::TryLoadModel(iComponentID)) {
			FLog("Component Model not loaded");
			return;
	} 
	if (!ScriptCommand(&is_component_available, iComponentID)) {
		return;
	}

	uint32_t dwRet;
	ScriptCommand(&add_car_component, m_dwGTAId, iComponentID, &dwRet);
}
// 0.3.7
void CVehicle::SetPaintJob(uint8_t bytePaintJobID)
{
	if (m_pVehicle && GamePool_Vehicle_GetAt(m_dwGTAId))
	{
		if (GetVehicleSubtype() == VEHICLE_SUBTYPE_CAR)
		{
			if (bytePaintJobID >= 0 && bytePaintJobID <= 3) {
                if (m_dwGTAId) ScriptCommand(&change_car_skin, m_dwGTAId, bytePaintJobID);
			}
		}
	}
}
// 0.3.7
void CVehicle::SetColor(uint8_t byteColor1, uint8_t byteColor2)
{
	if (m_pVehicle && GamePool_Vehicle_GetAt(m_dwGTAId))
	{
		m_pVehicle->m_nPrimaryColor = byteColor1;
		m_pVehicle->m_nSecondaryColor = byteColor2;
	}

	m_byteColor1 = byteColor1;
	m_byteColor2 = byteColor2;
	m_bHaveColor = true;
}
// 0.3.7
void CVehicle::DetachTrailer()
{
	bInProcessDetachTrailer = true;
	if (m_pTrailer)
	{
		if (m_dwGTAId && GamePool_Vehicle_GetAt(m_dwGTAId))
		{
			if (m_pTrailer->m_pVehicle)
				ScriptCommand(&detach_trailer_from_cab, m_pTrailer->m_dwGTAId, m_dwGTAId);
		}
	}
}
// 0.3.7
void CVehicle::SetTrailer(CVehicle* pTrailer)
{
	m_pTrailer = pTrailer;
}
// 0.3.7
void CVehicle::LinkToInterior(int iInterior)
{
	if(m_pVehicle)
        m_pVehicle->SetInterior(iInterior);
}

void CVehicle::SetDamageStatus(uint32_t dwPanelDamageStatus, uint32_t dwDoorDamageStatus, uint8_t byteLightDamageStatus)
{

}

void CVehicle::SetTireDamageStatus(uint8_t byteTireDamageStatus)
{

}
// 0.3.7
void CVehicle::RemoveEveryoneFromVehicle()
{
	if (!m_pVehicle) return;
	if (!GamePool_Vehicle_GetAt(m_dwGTAId)) return;

    if (!m_pVehicle) return;
    if(!m_dwGTAId)return;
    if (!GamePool_Vehicle_GetAt(m_dwGTAId)) return;

    if (m_pVehicle->pDriver)
    {
        m_pVehicle->pDriver->RemoveFromVehicle();
    }

    for (int i = 0; i < 7; i++)
    {
        if (m_pVehicle->m_apPassengers[i] != nullptr)
        {
            m_pVehicle->m_apPassengers[i]->RemoveFromVehicle();
        }
    }
}
// 0.3.7
CVehicle* CVehicle::GetTrailer()
{
	if (m_pVehicle)
	{
        CVehicleGTA* pTrailer = m_pVehicle->m_pTrailer;
		if (pTrailer)
		{
			if (pNetGame)
			{
				CVehiclePool* pVehiclePool = pNetGame->GetVehiclePool();
				if (pVehiclePool) {
					VEHICLEID TrailerID = pVehiclePool->FindIDFromGtaPtr(pTrailer);
					if (TrailerID != INVALID_VEHICLE_ID)
					{
						return pVehiclePool->GetAt(TrailerID);
					}
				}
			}
		}
	}

	return nullptr;
}
// 0.3.7
CVehicle* CVehicle::GetTractor()
{
	if (!m_pVehicle) return nullptr;

	int iSubType = ::GetVehicleSubtype(m_pVehicle);
	if (iSubType == VEHICLE_SUBTYPE_BIKE
		|| iSubType == VEHICLE_SUBTYPE_BOAT
		|| iSubType == VEHICLE_SUBTYPE_TRAIN
		|| iSubType == VEHICLE_SUBTYPE_PUSHBIKE)
	{
		return nullptr;
	}

    CVehicleGTA* pTractor = m_pVehicle->m_pTowingVehicle;
	if (pTractor)
	{
		if (pNetGame)
		{
			CVehiclePool* pVehiclePool = pNetGame->GetVehiclePool();
			if (pVehiclePool)
			{
				VEHICLEID TrailerID = pVehiclePool->FindIDFromGtaPtr(pTractor);
				if (TrailerID != INVALID_VEHICLE_ID)
				{
					return pVehiclePool->GetAt(TrailerID);
				}
			}
		}
	}

	return nullptr;
}
// 0.3.7
float CVehicle::GetTrainSpeed()
{
	//if (m_pVehicle) {
	//	return m_pVehicle->fTrainSpeed;
	//}
	
	return 0.0f;
}
// 0.3.7 (dword -> word)
uint16_t CVehicle::GetHydraThrusters()
{
	//if (m_pVehicle) {
	//	return m_pVehicle->wHydraThrusters;
	//}

	return 0.0f;
}

bool CVehicle::IsLandingGearNotUp()
{
	//if(m_pVehicle)
		//return m_pVehicle->fPlaneLandingGear != 0.0f;

	return 0;
}

float CVehicle::GetBikeLean()
{
	//if (m_pVehicle && GamePool_Vehicle_GetAt(m_dwGTAId))
		//return m_pVehicle->fBikeLean;

	return 0.0f;
}
// 0.3.7
bool CVehicle::IsATrainPart()
{
	if (m_pVehicle)
	{
		int iModelIndex = m_pVehicle->m_nModelIndex;
		if (iModelIndex == 538 || iModelIndex == 570 || iModelIndex == 537 ||
			iModelIndex == 569 || iModelIndex == 449) {
			return true;
		}
	}

	return false;
}
// 0.3.7
bool CVehicle::VerifyInstance()
{
	return GamePool_Vehicle_GetAt(m_dwGTAId) != nullptr;
}
// 0.3.7
void CVehicle::SetDoorState(int state)
{
	if (state)
	{
		m_pVehicle->m_nDoorLock = (eCarLock)2;
		m_bDoorsLocked = true;
	}
	else
	{
		m_pVehicle->m_nDoorLock =(eCarLock) 0;
		m_bDoorsLocked = false;
	}
}

void CVehicle::SetComponentOpenState(int iDoor, int iComponent, float fDoorOpenRatio)
{
	if (GetVehicleSubtype() == VEHICLE_SUBTYPE_CAR)
	{
		ScriptCommand(&set_car_door_rotation_to, m_dwGTAId, iDoor, iComponent, fDoorOpenRatio);
	
	}
}

void CVehicle::OpenWindow(uint8_t component)
{
	if (m_pVehicle) {

	}
}

void CVehicle::CloseWindow(uint8_t component)
{
	if (m_pVehicle) {

	}
}
// 0.3.7
void CVehicle::AttachTrailer()
{
	if (m_pTrailer) {
		ScriptCommand(&put_trailer_on_cab, m_pTrailer->m_dwGTAId, m_dwGTAId);
	}
}
// 0.3.7
void CVehicle::RemoveComponent(int iComponentID)
{
	if (!m_pVehicle || !GamePool_Vehicle_GetAt(m_dwGTAId))
		return;

	ScriptCommand(&remove_component, m_dwGTAId, iComponentID);
}
// 0.3.7
void CVehicle::SetZAngle(float fAngle)
{
	if (GamePool_Vehicle_GetAt(m_dwGTAId)) {
		ScriptCommand(&set_car_z_angle, m_dwGTAId, fAngle);
	}
}
// 0.3.7
bool CVehicle::IsDriverLocalPlayer()
{
	if (m_pVehicle && m_pVehicle->pDriver == GamePool_FindPlayerPed())
		return true;

	return false;
}
// 0.3.7
void CVehicle::SetInvulnerable(bool bInv)
{
	if (m_pVehicle && GamePool_Vehicle_GetAt(m_dwGTAId))
	{
		if (bInv)
		{
			ScriptCommand(&set_car_immunities, m_dwGTAId, 1, 1, 1, 1, 1);
			ScriptCommand(&toggle_car_tires_vulnerable, m_dwGTAId, 0);
			m_bIsInvulnerable = true;
		}
		else
		{
			ScriptCommand(&set_car_immunities, m_dwGTAId, 0, 0, 0, 0, 0);
			ScriptCommand(&toggle_car_tires_vulnerable, m_dwGTAId, 1);
			m_bIsInvulnerable = false;
		}
	}
}
// 0.3.7
bool CVehicle::HasSunk()
{
	if (m_pVehicle) {
		return ScriptCommand(&has_car_sunk, m_dwGTAId);
	}

	return false;
}
// 0.3.7
bool CVehicle::HasADriver()
{
	if (m_pVehicle && GamePool_Vehicle_GetAt(m_dwGTAId))
	{
		if (m_pVehicle->pDriver)
		{
			if (m_pVehicle->pDriver->IsInVehicle() &&
				m_pVehicle->pDriver->m_nPedType == (ePedType)0)
				return true;
		}
	}

	return false;
}

void CVehicle::ApplyEngineState(int iState)
{
	if (!m_pVehicle) return;

	m_iEngineState = iState;

    m_pVehicle->m_nVehicleFlags.bEngineOn = iState;
}

void CVehicle::ApplyLightState(int iState)
{
	if (!m_pVehicle) return;
	//if(iState > 1)
	//	return;

	m_iLightState = iState;
    m_pVehicle->m_nVehicleFlags.bLightsOn = iState;
}
// 0.3.7
void CVehicle::ProcessMarkers()
{
	if(!m_pVehicle || !GamePool_Vehicle_GetAt(m_dwGTAId))
		return;

	if(m_byteObjectiveVehicle)
	{
		if(!m_bSpecialMarkerEnabled)
		{
			if(m_dwMarkerID)
			{
				pGame->DisableMarker(m_dwMarkerID);
				m_dwMarkerID = 0;
			}

			ScriptCommand(&tie_marker_to_car, m_dwGTAId, 1, 3, &m_dwMarkerID);
			ScriptCommand(&set_marker_color, m_dwMarkerID, 1006);
			ScriptCommand(&show_on_radar, m_dwMarkerID, 3);
			m_bSpecialMarkerEnabled = true;
		}

		return;
	}

	if(m_byteObjectiveVehicle && m_bSpecialMarkerEnabled)
	{
		if(m_dwMarkerID)
		{
			pGame->DisableMarker(m_dwMarkerID);
			m_dwMarkerID = 0;

			m_bSpecialMarkerEnabled = false;
		}
	}

	if(m_pVehicle->GetDistanceFromLocalPlayerPed() < 200.0f && GetTractor() == NULL &&
	   !IsOccupied())
	{
		if(!m_dwMarkerID)
		{
			ScriptCommand(&tie_marker_to_car, m_dwGTAId, 1, 2, &m_dwMarkerID);
			ScriptCommand(&set_marker_color, m_dwMarkerID, 1004);
		}
	}

	else if(IsOccupied() || GetTractor() != NULL ||
            m_pVehicle->GetDistanceFromLocalPlayerPed() >= 200.0f)
	{
		if(m_dwMarkerID)
		{
			pGame->DisableMarker(m_dwMarkerID);
			m_dwMarkerID = 0;
		}
	}
}
// 0.3.7
bool CVehicle::IsOccupied()
{
	if (m_pVehicle)
	{
		if (m_pVehicle &&
			(m_pVehicle->m_apPassengers[0] ||
			m_pVehicle->m_apPassengers[1] ||
			m_pVehicle->m_apPassengers[2] ||
			m_pVehicle->m_apPassengers[3] ||
			m_pVehicle->m_apPassengers[4] ||
			m_pVehicle->m_apPassengers[5] ||
			m_pVehicle->m_apPassengers[6])) {
			return true;
		}
	}

	return false;
}

bool CVehicle::IsATowTruck()
{
	if(!m_pVehicle) return false;
	return m_pVehicle->m_nModelIndex == 525;
}

bool CVehicle::IsATrailer()
{
	if(!m_pVehicle) return false;

  	int nModel = m_pVehicle->m_nModelIndex;
	return (nModel == 435 ||
		nModel == 450 || 
		nModel == 584 || 
		nModel == 591 || 
		nModel == 606 || 
		nModel == 607 || 
		nModel == 608 || 
		nModel == 610 || 
		nModel == 611
	);
}

void CVehicle::UpdateDamageStatus(uint32_t dwPanelDamage, uint32_t dwDoorDamage, uint8_t byteLightDamage)
{
	if(m_pVehicle)
	{
		if(GetVehicleSubtype() == VEHICLE_SUBTYPE_CAR)
		{
			if(!dwPanelDamage && !dwDoorDamage && !byteLightDamage)
			{
				if(GetPanelDamageStatus() || GetDoorDamageStatus() || GetLightDamageStatus())
				{
					// CAutoMobile::Fix
					(( void (*)(CVehicleGTA*))(g_libGTASA+(VER_x32 ? 0x55D5C0+1:0x67DF0C)))(m_pVehicle);
					return;
				}
			}

			SetDoorDamageStatus(dwDoorDamage);
			SetPanelDamageStatus(dwPanelDamage);
			SetLightDamageStatus(byteLightDamage);

			// CAutomobile::SetupDamageAfterLoad
			(( void (*)(CVehicleGTA*))(g_libGTASA+(VER_x32 ? 0x55D886+1:0x67E368)))(m_pVehicle);
		}
	}
}

void CVehicle::SetPanelDamageStatus(uint32_t dwPanelStatus)
{
	//if(m_pVehicle && GetVehicleSubtype() == VEHICLE_SUBTYPE_CAR)
		//m_pVehicle->dwPanelStatus = dwPanelStatus;
}

uint32_t CVehicle::GetPanelDamageStatus()
{
	//if(m_pVehicle && GetVehicleSubtype() == VEHICLE_SUBTYPE_CAR)
		//return m_pVehicle->dwPanelStatus;

	return 0;
}

void CVehicle::SetDoorDamageStatus(uint32_t dwDoorStatus)
{
	/*if(m_pVehicle && GetVehicleSubtype() == VEHICLE_SUBTYPE_CAR)
	{
		m_pVehicle->byteDoorStatus[0] = dwDoorStatus & 7;
		m_pVehicle->byteDoorStatus[1] = (dwDoorStatus >> 8) & 7;
		m_pVehicle->byteDoorStatus[2] = (dwDoorStatus >> 16) & 7;
		m_pVehicle->byteDoorStatus[3] = (dwDoorStatus >> 24) & 7;
	}*/
}

uint32_t CVehicle::GetDoorDamageStatus()
{
	/*if(m_pVehicle && GetVehicleSubtype() == VEHICLE_SUBTYPE_CAR)
	{
		uint32_t dwDoorStatus = (m_pVehicle->byteDoorStatus[0] | (m_pVehicle->byteDoorStatus[1] << 8) | (m_pVehicle->byteDoorStatus[2] << 16) | (m_pVehicle->byteDoorStatus[3] << 24));
		return dwDoorStatus;
	}*/

	return 0;
}

void CVehicle::SetLightDamageStatus(uint8_t byteLightStatus)
{
	//if(m_pVehicle && GetVehicleSubtype() == VEHICLE_SUBTYPE_CAR)
		//m_pVehicle->dwLightStatus = (uint32_t)byteLightStatus;
}

uint8_t CVehicle::GetLightDamageStatus()
{
	//if(m_pVehicle && GetVehicleSubtype() == VEHICLE_SUBTYPE_CAR)
		//return (uint8_t)m_pVehicle->dwLightStatus;

	return 0;
}

void CVehicle::SetWheelPoppedStatus(uint8_t byteWheelStatus)
{
	/*if(m_pVehicle)
	{
		if(GetVehicleSubtype() == VEHICLE_SUBTYPE_CAR)
		{
			m_pVehicle->byteWheelStatus[3] = byteWheelStatus & 1;
			m_pVehicle->byteWheelStatus[2] = (byteWheelStatus >> 1) & 1;
			m_pVehicle->byteWheelStatus[1] = (byteWheelStatus >> 2) & 1;
			m_pVehicle->byteWheelStatus[0] = (byteWheelStatus >> 3) & 1;
		}
		else if(GetVehicleSubtype() == VEHICLE_SUBTYPE_BIKE)
		{
			m_pVehicle->byteBikeWheelStatus[1] = byteWheelStatus & 1;
			m_pVehicle->byteBikeWheelStatus[0] = (byteWheelStatus >> 1) & 1;
		}
	}*/
}

uint8_t CVehicle::GetWheelPoppedStatus()
{
	/*if(m_pVehicle)
	{
		if(GetVehicleSubtype() == VEHICLE_SUBTYPE_CAR)
		{
			uint8_t byteWheelStatus = (m_pVehicle->byteWheelStatus[3] | (m_pVehicle->byteWheelStatus[2] << 1) | (m_pVehicle->byteWheelStatus[1] << 2) | (m_pVehicle->byteWheelStatus[0] << 3));
			return byteWheelStatus;
		}
		else if(GetVehicleSubtype() == VEHICLE_SUBTYPE_BIKE)
		{
			uint8_t byteWheelStatus = (m_pVehicle->byteBikeWheelStatus[1] | (m_pVehicle->byteBikeWheelStatus[0] << 1));
			return byteWheelStatus;
		}
	}*/

	return 0;
}

bool CVehicle::SirenEnabled()
{
	if(!m_pVehicle)
		return m_pVehicle->m_nVehicleFlags.bSirenOrAlarm;

	return false;
}

void CVehicle::EnableSiren(bool bState)
{
	if(!m_pVehicle) return;

	m_pVehicle->m_nVehicleFlags.bSirenOrAlarm = (int)bState;
}

void CVehicle::UpdateColor()
{
	if(m_pVehicle)
	{
		if(m_bHaveColor)
		{
			if(!m_bHasBeenDriven)
			{
				if(m_pVehicle->m_nPrimaryColor != m_byteColor1 || m_pVehicle->m_nSecondaryColor != m_byteColor2)
				{
					m_pVehicle->m_nPrimaryColor = m_byteColor1;
					m_pVehicle->m_nSecondaryColor = m_byteColor2;
				}
			}
		}
	}
}

bool CVehicle::UpdateLastDrivenTime()
{
	if(m_pVehicle)
	{
		if(m_pVehicle->pDriver)
		{
			m_bHasBeenDriven = true;
			m_dwTimeSinceLastDriven = GetTickCount();
			return true;
		}
	}

	return false;
}


void CVehicle::SetHandlingData(std::vector<SHandlingData>& vHandlingData)
{
    if (!m_pVehicle || !m_dwGTAId)
    {
        return;
    }
    if (!GamePool_Vehicle_GetAt(m_dwGTAId))
    {
        return;
    }

    if (GetVehicleSubtype() != VEHICLE_SUBTYPE_CAR)
    {
        return;
    }


//	if (!m_pCustomHandling)
//	{
//		m_pCustomHandling = new tHandlingData;
//	}

    uintptr_t* dwModelarray = (uintptr_t*)(g_libGTASA + (VER_x32 ? 0x0091DCB8 : 0xB666E0));
    CVehicleModelInfo* pModelInfoStart = CModelInfo::GetVehicleModelInfo(m_pVehicle->m_nModelIndex);
    if (!pModelInfoStart)
    {
        return;
    }

    //CChatWindow::AddDebugMessage("handling id %d", *(uint16_t*)(pModelInfoStart + 98));

    CHandlingDefault::GetDefaultHandling(pModelInfoStart->m_nHandlingId, m_pCustomHandling);

    //CChatWindow::AddDebugMessage("mass %f", m_pCustomHandling->m_fMass);
    //CChatWindow::AddDebugMessage("turn %f", m_pCustomHandling->m_fTurnMass);
    //CChatWindow::AddDebugMessage("m_fEngineAcceleration %f", m_pCustomHandling->m_transmissionData.m_fEngineAcceleration);
    //CChatWindow::AddDebugMessage("m_fMaxGearVelocity %f", m_pCustomHandling->m_transmissionData.m_fMaxGearVelocity);
    //CChatWindow::AddDebugMessage("flags 0x%x", m_pCustomHandling->m_nHandlingFlags);

    bool bNeedRecalculate = false;

    for (auto& i : vHandlingData)
    {
        switch (i.flag)
        {
            case E_HANDLING_PARAMS::hpMaxSpeed:
                m_pCustomHandling->m_transmissionData.m_fMaxGearVelocity = i.fValue * 0.84;
                break;
            case E_HANDLING_PARAMS::hpAcceleration: {
                float sampSpeed = m_pCustomHandling->m_transmissionData.m_fMaxGearVelocity * 1.2f;
                m_pCustomHandling->m_transmissionData.m_fEngineAcceleration = sampSpeed / 12.0f;
//				m_pCustomHandling->m_transmissionData.m_fEngineAcceleration =  i.fValue;
                break;
            }
            case E_HANDLING_PARAMS::hpEngineInertion:
                m_pCustomHandling->m_transmissionData.m_fEngineInertia = i.fValue;
                break;
            case E_HANDLING_PARAMS::hpGear:

                if (i.fValue == 1)
                {
                    m_pCustomHandling->m_transmissionData.m_nDriveType = 'R';
                }

                if (i.fValue == 2)
                {
                    m_pCustomHandling->m_transmissionData.m_nDriveType = 'F';
                }

                if (i.fValue == 3)
                {
                    m_pCustomHandling->m_transmissionData.m_nDriveType = '4';
                }

                break;
            case E_HANDLING_PARAMS::hpMass:
                m_pCustomHandling->m_fMass = i.fValue;
                break;
            case E_HANDLING_PARAMS::hpMassTurn:
                m_pCustomHandling->m_fTurnMass = i.fValue;
                break;
            case E_HANDLING_PARAMS::hpBrakeDeceleration:
            {
                m_pCustomHandling->m_fBrakeDeceleration = i.fValue;
                break;
            }
            case E_HANDLING_PARAMS::hpTractionMultiplier:
            {
                m_pCustomHandling->m_fTractionMultiplier = i.fValue;
                break;
            }
            case E_HANDLING_PARAMS::hpTractionLoss:
            {
                m_pCustomHandling->m_fTractionLoss = i.fValue;
                break;
            }
            case E_HANDLING_PARAMS::hpTractionBias:
            {
                m_pCustomHandling->m_fTractionBias = i.fValue;
                break;
            }
            case E_HANDLING_PARAMS::hpSuspensionLowerLimit:
            {
                m_pCustomHandling->m_fSuspensionLowerLimit = i.fValue;
                bNeedRecalculate = true;
                break;
            }
            case E_HANDLING_PARAMS::hpSuspensionBias:
            {
                m_pCustomHandling->m_fSuspensionBiasBetweenFrontAndRear = i.fValue;
                bNeedRecalculate = true;
                break;
            }
            case E_HANDLING_PARAMS::hpWheelSize:
            {
                m_bWheelSize = true;
                m_fWheelSize = i.fValue;
                bNeedRecalculate = true;
                break;
            }
        }
    }

    float fOldFrontWheelSize = 0.0f;
    float fOldRearWheelSize = 0.0f;

    if (m_bWheelSize)
    {
        fOldFrontWheelSize = pModelInfoStart->m_fWheelSizeFront;
        pModelInfoStart->m_fWheelSizeFront = m_fWheelSize;

        fOldRearWheelSize = pModelInfoStart->m_fWheelSizeRear;
        pModelInfoStart->m_fWheelSizeRear = m_fWheelSize;
    }

    /*CChatWindow::AddDebugMessage("AFTER");
    CChatWindow::AddDebugMessage("mass %f", m_pCustomHandling->m_fMass);
    CChatWindow::AddDebugMessage("turn %f", m_pCustomHandling->m_fTurnMass);
    CChatWindow::AddDebugMessage("m_fEngineAcceleration %f", m_pCustomHandling->m_transmissionData.m_fEngineAcceleration);
    CChatWindow::AddDebugMessage("m_fMaxGearVelocity %f", m_pCustomHandling->m_transmissionData.m_fMaxGearVelocity);
    CChatWindow::AddDebugMessage("flags 0x%x", m_pCustomHandling->m_nHandlingFlags);*/

//	((void (*)(int, tHandlingData*))(g_libGTASA + 0x00570DC8 + 1))(0, m_pCustomHandling);
//	m_pVehicle->pHandling = m_pCustomHandling;
//
//	if (bNeedRecalculate)
//	{
//		((void (*)(CVehicleGta*))(g_libGTASA + 0x0054EC38 + 1))(m_pVehicle); // CAutomobile::SetupSuspensionLines
//
//		CopyGlobalSuspensionLinesToPrivate();
//	}

    if (m_bWheelSize)
    {
        pModelInfoStart->m_fWheelSizeFront = fOldFrontWheelSize;
        pModelInfoStart->m_fWheelSizeRear = fOldRearWheelSize;
    }

    if (bNeedRecalculate)
    {
        ((void (*)(CVehicleGTA*))(g_libGTASA + (VER_x32 ? 0x0055F430 + 1 : 0x68036C)))(m_pVehicle); // process suspension
    }
    //ScriptCommand(&set_car_heavy, m_dwGTAId, 1);
}