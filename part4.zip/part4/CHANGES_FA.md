# تغییرات اعمال‌شده

1. GTASA.java: شرط SignatureChecker معکوس بود و بازی اجرا نمی‌شد (اصلاح شد).
2. LoadGameActivity: جلوگیری از Zip Slip، محدودیت حجم بعد از استخراج، بررسی SHA-256 (مقدار CACHE_SHA256 را پر کنید)، حذف cache_url از Analytics.
3. مسیرها: com.glory.game -> com.gloryrp.app در LoadGameActivity، HomeActivity، SettingsActivity.
4. DownloadActivity: authority فایل‌پرووایدر ".provider" به ".fileprovider" اصلاح شد (نصب APK کرش می‌کرد).
5. network_security_config: cleartext و گواهی کاربر غیرفعال شد؛ usesCleartextTraffic=false.
6. file_paths.xml: به پوشه‌های لازم (GloryMobile/ و پوشه‌های خود برنامه) محدود شد.
7. Manifest: حذف RECEIVE_BOOT_COMPLETED، USE_FULL_SCREEN_INTENT و INSTALL_REFERRER.
8. DonateFragment: غیرفعال‌سازی دسترسی فایل/جئولوکیشن در WebView.
9. FirebaseMessageReceiver: فقط https و timeout برای دانلود تصویر.
10. App.java: logcat فقط برای همین پروسه؛ isAppInstalledFromMarket امن در برابر null.
11. build.gradle ریشه: حذف مخزن‌های splunk و applovin و sonatype snapshots.
12. README با NDK/AGP واقعی هماهنگ شد.

# باید خودتان انجام دهید
- Links.java: MANIFEST_URL و لینک‌های example.com / YourChannel را با مقادیر واقعی پر کنید.
- CACHE_SHA256 در LoadGameActivity را با هش واقعی cache.zip پر کنید.
- فایل‌های libGTASA.so و دیتای Rockstar را قبل از انتشار عمومی بررسی حقوقی کنید.
- پروژه کامپایل نشده (SDK/NDK در دسترس نبود)؛ یک بار با gradlew assembleVer_releaseRelease تست کنید.

# تغییرات برند Dexin Mobile
- نام اپ، عنوان‌ها، User-Agent و versionName به Dexin Mobile / DEXIN تغییر کرد.
- سرور داخل برنامه ثبت شد: 5.57.37.28:3333 (Config.DEFAULT_SERVER_*) و در لیست سرورها نمایش داده می‌شود.
- settings.ini پیش‌فرض و settings.ini نمونه به همین سرور اشاره می‌کنند.
- API_LINK خالی است (لیست سرور از API نمی‌آید). لینک‌های Discord/VK/YouTube خالی‌اند و دکمه‌هایشان بدون کرش هیچ کاری نمی‌کنند.
- پکیج (com.gloryrp.app) و نام پوشه‌ی GloryMobile تغییر نکرد.

# پورت و GitHub
- سرور: 5.57.37.28:3333
- workflow بیلد: .github/workflows/build.yml (راهنما در GITHUB_BUILD_FA.md)
- خطوط gradle-wrapper از .gitignore حذف شد.

# وصله‌ی کرش رندر (SIGSEGV fault 0x40)
- hooks.cpp / CheckResEntryValid: وقتی تکسچر یا ماده‌ی یک mesh نامعتبر است، بیت‌های تکسچر (0x84) از flags حذف می‌شوند تا بازی به RwTexture null دست نزند. آن mesh بدون تکسچر کشیده می‌شود.
- هنوز کامپایل نشده؛ علت اصلی (تکسچر/مدل ناقص در دیتا یا اشیای سرور) باقی می‌ماند.

# اصلاح ریشه‌ای کرش رندر (۶۴ بیت)
- علت: در اندروید ۱۱+ اشاره‌گرهای heap در بایت بالا tag دارند (مثل 0xb400007430b924b0). بررسی بازه در hooks.cpp (IsValidAddress و شاخه‌ی ۶۴ بیتی CheckResEntryValid) این اشاره‌گرهای سالم را نامعتبر می‌دانست، متریال را با متریال بدون تکسچر عوض می‌کرد و بازی هنگام خواندن RwTexture::mask (offset 0x40) کرش می‌کرد.
- راه‌حل: تابع UntagPtr اضافه شد و قبل از همه‌ی بررسی‌های بازه، tag حذف می‌شود.
- حذف بیت‌های تکسچر از flags فقط برای مواردی که واقعاً نامعتبرند باقی ماند (شبکه‌ی ایمنی).

# اصلاح سرریز بافر قابل‌تحریک از سرور
- scriptrpc.cpp: بافر szFontName از ۳۲ به ۲۵۷ بایت (طول از شبکه تا ۲۵۵ می‌آمد).
- playerpool.cpp/.h: strcpy نام بازیکن به strncpy با MAX_PLAYER_NAME (نام تا ۲۵۵ بایت از سرور و بافر ۲۵ بایتی).
- playerbubblepool.cpp: متن حباب بعد از تبدیل به UTF-8 بیش از ۲۵۶ بایت می‌شد؛ اکنون برش می‌خورد.
- playerped.cpp: نام انیمیشن/بلاک در بافر ۴۰ بایتی با strncpy.

# سرور
- آدرس سرور: 5.57.37.28:3333 و نام نمایشی سرور: Legendary Samp (Config.DEFAULT_SERVER_*).
